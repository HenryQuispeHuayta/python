
lista = []

for numero in range(100):
  lista.append(numero+1)

lista.sort(reverse=True)
print(lista)